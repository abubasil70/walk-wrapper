package main

import (
	"os"

	"github.com/lxn/walk"
	. "github.com/lxn/walk/declarative"
)

// App represents the main application structure holding configuration and widgets.
type App struct {
	Title    string
	Width    int
	Height   int
	IconPath string
	Children []Widget      // List of widgets to be rendered
	Window   *walk.MainWindow
}

// NewGui initializes a new application instance.
func NewGui(title string, w, h int) *App {
	return &App{
		Title:  title,
		Width:  w,
		Height: h,
	}
}

// SetIcon sets the application icon safely.
func (a *App) SetIcon(path string) {
	if _, err := os.Stat(path); err == nil {
		a.IconPath = path
	}
}

// Run constructs the window and starts the main event loop.
func (a *App) Run() {
	mw := MainWindow{
		AssignTo: &a.Window,
		Title:    a.Title,
		MinSize:  Size{Width: a.Width, Height: a.Height},
		
		Layout:   VBox{}, 
		Children: a.Children,

		// الخط العريض
		Font: Font{
			Family:    "Segoe UI",
			PointSize: 10,
			Bold:      true,
		},

		// هذا يجعل اتجاه القراءة من اليمين
		RightToLeftReading: true, 
	}

	if a.IconPath != "" {
		mw.Icon = a.IconPath
	}

	mw.Run()
}

// ---------------------------------------------------------
// Layout Tools
// ---------------------------------------------------------

func (a *App) AddRow(buildFunc func(row *App)) {
	tempRow := &App{}
	buildFunc(tempRow)

	// الحيلة هنا: نضيف Spacer في البداية لدفع العناصر لليمين
	children := []Widget{HSpacer{}} 
	children = append(children, tempRow.Children...)

	a.Children = append(a.Children, Composite{
		Layout:   HBox{MarginsZero: true}, 
		Children: children,
	})
}

func (a *App) AddGroupBox(title string, buildFunc func(group *App)) {
	tempGroup := &App{}
	buildFunc(tempGroup)

	a.Children = append(a.Children, GroupBox{
		Title:    title,
		Layout:   VBox{}, 
		Children: tempGroup.Children,
	})
}

func (a *App) AddComposite(layout Layout, buildFunc func(comp *App)) {
	tempComp := &App{}
	buildFunc(tempComp)

	a.Children = append(a.Children, Composite{
		Layout:   layout,
		Children: tempComp.Children,
	})
}

func (a *App) AddSplitter(isVertical bool, buildFunc func(split *App)) {
	tempSplit := &App{}
	buildFunc(tempSplit)

	if isVertical {
		a.Children = append(a.Children, VSplitter{
			Children: tempSplit.Children,
		})
	} else {
		a.Children = append(a.Children, HSplitter{
			Children: tempSplit.Children,
		})
	}
}

// ---------------------------------------------------------
// Basic Widgets
// ---------------------------------------------------------

func (a *App) AddLabel(txt string) {
	a.Children = append(a.Children, Label{
		Text: txt,
		// Label يدعم المحاذاة، نستخدم AlignFar من مكتبة walk
		TextAlignment: AlignFar, 
	})
}

func (a *App) AddInput(ptr **walk.LineEdit) {
	a.Children = append(a.Children, LineEdit{
		AssignTo: ptr,
	})
}

func (a *App) AddPasswordInput(ptr **walk.LineEdit) {
	a.Children = append(a.Children, LineEdit{
		AssignTo:     ptr,
		PasswordMode: true,
	})
}

func (a *App) AddEdit(ptr **walk.TextEdit) {
	a.Children = append(a.Children, TextEdit{
		AssignTo: ptr, 
		VScroll: true,
	})
}

func (a *App) AddReadOnlyEdit(ptr **walk.TextEdit) {
	a.Children = append(a.Children, TextEdit{
		AssignTo: ptr,
		ReadOnly: true,
		VScroll:  true,
	})
}

func (a *App) AddButton(txt string, onClick func()) {
	a.Children = append(a.Children, PushButton{
		Text:      txt,
		OnClicked: onClick,
	})
}

func (a *App) AddCheck(txt string, ptr **walk.CheckBox) {
	a.Children = append(a.Children, CheckBox{
		Text: txt, 
		AssignTo: ptr,
		// حذفنا TextAlignment لأنها غير مدعومة هنا
	})
}

func (a *App) AddRadioButton(txt string, ptr **walk.RadioButton) {
	a.Children = append(a.Children, RadioButton{
		Text:     txt,
		AssignTo: ptr,
		// حذفنا TextAlignment لأنها غير مدعومة هنا
	})
}

func (a *App) AddCombo(items []string, ptr **walk.ComboBox) {
	a.Children = append(a.Children, ComboBox{
		AssignTo:     ptr,
		Model:        items,
		CurrentIndex: 0,
	})
}

func (a *App) AddListBox(items []string, ptr **walk.ListBox) {
	a.Children = append(a.Children, ListBox{
		AssignTo: ptr,
		Model:    items,
	})
}

func (a *App) AddSpacer() {
	a.Children = append(a.Children, VSpacer{})
}

func (a *App) AddHSpacer() {
	a.Children = append(a.Children, HSpacer{})
}

// AddSeparator adds a horizontal line separator.
func (a *App) AddSeparator() {
	a.Children = append(a.Children, Composite{
		MaxSize: Size{Height: 2},
		MinSize: Size{Height: 2},
		Background: SolidColorBrush{Color: walk.RGB(160, 160, 160)}, 
	})
}

// ---------------------------------------------------------
// Advanced Input Widgets
// ---------------------------------------------------------

func (a *App) AddSlider(min, max int, ptr **walk.Slider) {
	a.Children = append(a.Children, Slider{
		AssignTo: ptr,
		MinValue: min,
		MaxValue: max,
	})
}

func (a *App) AddProgressBar(ptr **walk.ProgressBar) {
	a.Children = append(a.Children, ProgressBar{
		AssignTo: ptr,
	})
}

func (a *App) AddNumberEdit(ptr **walk.NumberEdit) {
	a.Children = append(a.Children, NumberEdit{
		AssignTo: ptr,
	})
}

func (a *App) AddDateEdit(ptr **walk.DateEdit) {
	a.Children = append(a.Children, DateEdit{
		AssignTo: ptr,
	})
}

// ---------------------------------------------------------
// Display Widgets
// ---------------------------------------------------------

func (a *App) AddImageView(ptr **walk.ImageView) {
	a.Children = append(a.Children, ImageView{
		AssignTo: ptr,
	})
}

func (a *App) AddLinkLabel(txt string, onClick func()) {
	a.Children = append(a.Children, LinkLabel{
		Text:      txt,
		// حذفنا TextAlignment لأنها غير مدعومة هنا
		OnLinkActivated: func(link *walk.LinkLabelLink) {
			if onClick != nil {
				onClick()
			}
		},
	})
}

func (a *App) AddWebView(ptr **walk.WebView) {
	a.Children = append(a.Children, WebView{
		AssignTo: ptr,
	})
}

// ---------------------------------------------------------
// Table Support
// ---------------------------------------------------------

func (a *App) AddTable(ptr **walk.TableView, model interface{}, cols []TableViewColumn) {
	a.Children = append(a.Children, TableView{
		AssignTo:         ptr,
		AlternatingRowBG: true,
		Columns:          cols,
		Model:            model,
	})
}

func (a *App) AddTreeView(ptr **walk.TreeView, model walk.TreeModel) {
	a.Children = append(a.Children, TreeView{
		AssignTo: ptr,
		Model:    model,
	})
}

// ---------------------------------------------------------
// Menu & Toolbar Support
// ---------------------------------------------------------

func (a *App) AddToolBar(buildFunc func(tb *App)) {
	tempTB := &App{}
	buildFunc(tempTB)

	a.Children = append(a.Children, ToolBar{
		ButtonStyle: ToolBarButtonImageBeforeText,
		Items:       convertToActionList(tempTB.Children),
	})
}

func convertToActionList(widgets []Widget) []MenuItem {
	return []MenuItem{}
}

// ---------------------------------------------------------
// Dialog Helpers
// ---------------------------------------------------------

func ShowDialog(title string, width, height int, buildFunc func(dlg *App)) int {
	tempDlg := &App{}
	buildFunc(tempDlg)

	var dlg *walk.Dialog
	var acceptPB, cancelPB *walk.PushButton

	dialogChildren := append(tempDlg.Children, VSpacer{}) 
	
	// هنا أيضاً نستخدم حيلة الـ Spacer لجعل الأزرار تأتي على اليمين (أو اليسار حسب الترتيب)
	// لترتيب عربي (موافق ثم إلغاء على اليسار): Spacer -> OK -> Cancel
	// لترتيب عربي (الأزرار على اليمين): OK -> Cancel -> Spacer
	
	// سنجعل الأزرار في الوسط أو اليسار لأن ذلك أجمل في التصميم، أو يمكنك استخدام Spacer قبلها لدفعها لليمين
	dialogChildren = append(dialogChildren, Composite{
		Layout: HBox{},
		Children: []Widget{
			HSpacer{}, // يدفع الأزرار لليمين
			PushButton{
				AssignTo: &acceptPB,
				Text:     "موافق",
				OnClicked: func() {
					dlg.Accept()
				},
			},
			PushButton{
				AssignTo: &cancelPB,
				Text:     "إلغاء",
				OnClicked: func() {
					dlg.Cancel()
				},
			},
		},
	})

	result, _ := Dialog{
		AssignTo:      &dlg,
		Title:         title,
		DefaultButton: &acceptPB,
		CancelButton:  &cancelPB,
		MinSize:       Size{Width: width, Height: height},
		Layout:        VBox{},
		Children:      dialogChildren,
		Font:          Font{Family: "Segoe UI", PointSize: 10, Bold: true}, 
		RightToLeftReading: true,
	}.Run(nil)

	return result
}

// ---------------------------------------------------------
// Helper Functions
// ---------------------------------------------------------

func Msg(txt string) {
	walk.MsgBox(nil, "تنبيه", txt, walk.MsgBoxIconInformation)
}

func MsgError(txt string) {
	walk.MsgBox(nil, "خطأ", txt, walk.MsgBoxIconError)
}

func MsgWarning(txt string) {
	walk.MsgBox(nil, "تحذير", txt, walk.MsgBoxIconWarning)
}

func Confirm(txt string) bool {
	return walk.MsgBox(nil, "تأكيد", txt, walk.MsgBoxOKCancel|walk.MsgBoxIconQuestion) == walk.DlgCmdOK
}

func YesNo(txt string) bool {
	return walk.MsgBox(nil, "سؤال", txt, walk.MsgBoxYesNo|walk.MsgBoxIconQuestion) == walk.DlgCmdYes
}

func SelectFile(filter string) string {
	dlg := walk.FileDialog{
		Filter: filter,
		Title:  "اختر ملفاً",
	}

	if ok, _ := dlg.ShowOpen(nil); ok {
		return dlg.FilePath
	}
	return ""
}

func SaveFile(filter string) string {
	dlg := walk.FileDialog{
		Filter: filter,
		Title:  "حفظ الملف",
	}

	if ok, _ := dlg.ShowSave(nil); ok {
		return dlg.FilePath
	}
	return ""
}

func SelectFolder() string {
	dlg := walk.FileDialog{
		Title: "اختر مجلداً",
	}

	if ok, _ := dlg.ShowBrowseFolder(nil); ok {
		return dlg.FilePath
	}
	return ""
}