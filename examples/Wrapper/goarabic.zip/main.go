package main

import (
	"encoding/csv"
	"os"

	"github.com/lxn/walk"
	. "github.com/lxn/walk/declarative"
)

// ---------------------------------------------------------
// 1. Data Structure & Model (بقيت كما هي)
// ---------------------------------------------------------

type User struct {
	Name string
	City string
	Note string
}

type UserModel struct {
	walk.TableModelBase
	items []*User
}

func NewUserModel() *UserModel {
	return &UserModel{items: make([]*User, 0)}
}

func (m *UserModel) RowCount() int {
	return len(m.items)
}

func (m *UserModel) Value(row, col int) interface{} {
	item := m.items[row]
	switch col {
	case 0:
		return item.Name
	case 1:
		return item.City
	case 2:
		return item.Note
	}
	return nil
}

var myModel *UserModel

// ---------------------------------------------------------
// 2. Main Logic
// ---------------------------------------------------------

func main() {
	// تحميل البيانات الموجودة
	myModel = NewUserModel()
	myModel.items = loadUsers()

	// إنشاء النافذة باستخدام الرابر الجديد
	gui := NewGui("نظام إدارة المستخدمين - V2", 600, 650)
	gui.SetIcon("app.ico") // إذا كانت الأيقونة موجودة

	// تعريف المتغيرات لربطها واجهات الرسوم
	var nameInp *walk.LineEdit
	var cityCombo *walk.ComboBox
	var descEdit *walk.TextEdit
	var tv *walk.TableView

	// --- قسم الإدخال (استخدام ميزة GroupBox الجديدة) ---
	gui.AddGroupBox("بيانات المستخدم الجديد", func(box *App) {
		
		box.AddLabel("الاسم الكامل:")
		box.AddInput(&nameInp)

		box.AddLabel("المدينة:")
		box.AddCombo([]string{"البصرة", "بغداد", "أربيل", "دبي", "القاهرة"}, &cityCombo)

		box.AddLabel("ملاحظات إضافية:")
		box.AddEdit(&descEdit) // صندوق نص متعدد الأسطر
	})

	gui.AddSpacer()

	// --- أزرار التحكم ---
	gui.AddRow(func(row *App) {
		
		// زر الحفظ
		row.AddButton("حفظ البيانات", func() {
			// التحقق من الإدخال البسيط
			if nameInp.Text() == "" {
				MsgWarning("يرجى إدخال الاسم على الأقل!") // دالة جديدة في wrapper2
				return
			}

			u := &User{
				Name: nameInp.Text(),
				City: cityCombo.Text(),
				Note: descEdit.Text(),
			}

			if saveUserToCSV(u) {
				// تحديث الجدول
				myModel.items = append(myModel.items, u)
				myModel.PublishRowsReset()
				
				Msg("تم الحفظ بنجاح!")
				
				// تنظيف الحقول
				nameInp.SetText("")
				descEdit.SetText("")
			} else {
				MsgError("فشل في حفظ الملف!")
			}
		})

		row.AddHSpacer() // مسافة مرنة لدفع زر الخروج لليسار

		// زر الخروج
		row.AddButton("خروج", func() {
			// استخدام دالة YesNo الجديدة من wrapper2
			if YesNo("هل أنت متأكد أنك تريد إغلاق البرنامج؟") {
				walk.App().Exit(0)
			}
		})
	})

	gui.AddSpacer()

	// --- قسم الجدول ---
	gui.AddLabel("قائمة المستخدمين المسجلين:")
	
	// الجدول يبقى كما هو
	gui.AddTable(&tv, myModel, []TableViewColumn{
		{Title: "الاسم", Width: 200},
		{Title: "المدينة", Width: 100},
		{Title: "الملاحظات", Width: 250},
	})

	// تشغيل التطبيق
	gui.Run()
}

// ---------------------------------------------------------
// 3. Helper Functions (CSV)
// ---------------------------------------------------------

func saveUserToCSV(u *User) bool {
	f, err := os.OpenFile("users.csv", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return false
	}
	defer f.Close()

	writer := csv.NewWriter(f)
	defer writer.Flush()

	// التعامل مع الأحرف العربية يتطلب ترميزاً مناسباً، ولكن csv الافتراضي يعمل جيداً مع UTF-8
	return writer.Write([]string{u.Name, u.City, u.Note}) == nil
}

func loadUsers() []*User {
	var loaded []*User
	f, err := os.Open("users.csv")
	if err != nil {
		return loaded
	}
	defer f.Close()

	reader := csv.NewReader(f)
	records, _ := reader.ReadAll()

	for _, record := range records {
		if len(record) >= 3 {
			loaded = append(loaded, &User{
				Name: record[0],
				City: record[1],
				Note: record[2],
			})
		}
	}
	return loaded
}